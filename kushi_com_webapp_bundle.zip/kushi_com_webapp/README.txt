# Kushi.com — zero-budget prototype

## Included
- `index.html`: responsive Kannada/English demo app.
- EMI calculator.
- Processing fee calculator with illustrative GST toggle.
- Sample application form.
- Admin demo dashboard with status updates.
- Demo records saved only in this browser's local storage.

## Demo admin login
- Username: `admin`
- Password: `KushiDemo2026!`

This is a front-end demonstration gate, **not secure authentication**. The credentials are visible in the source code. Do not use this to protect real customer data.

## Important limitations
- No real lending, loan approval, disbursement, repayments, or fee collection.
- No server/database. Records are stored locally in the browser/device that created them and are not shared with an admin on another device.
- Do not enter real personal, identity, bank, credit-report, or financial information.
- Processing fee and GST amounts are illustrative only.

## Free hosting with GitHub Pages
1. Download and extract the ZIP.
2. Sign in at https://github.com/ and create a new public repository, e.g. `kushi-com-demo`.
3. Upload `index.html` to the repository root and commit the file.
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/(root)`, then save.
6. Wait for GitHub Pages to publish the site. Open the URL shown in Pages settings on your Android phone.
7. In Chrome, use **⋮ → Add to Home screen** to create a shortcut.

GitHub Pages availability and policies can change; review its current terms before publishing. A public static site means anyone can view the app source. This prototype contains no secrets.

## Before any real customer use
A shared database and proper authentication require a backend service, access rules, secure secret management, privacy/security review, and legal/regulatory review of the lending model. Do not simply add real customer data to this static prototype.
